# Asignación #1 · Principios de probabilidad y variables aleatorias

**Métodos de Investigación Aplicada · Módulo VIII**
Maestría en Ingeniería Eléctrica · Universidad Tecnológica de Panamá

Estudiante: Eric Arosemena · Docente: Dra. Yessica Sáez · Octubre de 2026

Este repositorio contiene el código que respalda la solución de la Asignación #1. Un único script de Python:

1. calcula los resultados numéricos de los 8 problemas;
2. contrasta 65 valores clave con los reportados en el documento de solución, y
3. genera las 6 figuras del documento, con etiquetas tomadas de los mismos cálculos.

## Contenido

| Archivo | Descripción |
|---|---|
| `asignacion1_EA.py` | Script único: cálculos, comprobación contra el documento y figuras |
| `requirements.txt` | Dependencias de Python |
| `figs/` | Figuras generadas por el script (PNG, 220 dpi) |

## Cómo ejecutarlo

Requiere Python 3.10 o superior.

```bash
pip install -r requirements.txt
python asignacion1_completo.py                      # verificación + figuras en ./figs
python asignacion1_completo.py --solo-verificacion  # solo cálculos y comprobación
python asignacion1_completo.py --solo-figuras --formato svg
python asignacion1_completo.py --detalle            # todos los valores sin redondear
```

La salida termina con `65 de 65 valores coinciden con el documento.` Si algún valor no coincide, el script lo marca como `DIFERENCIA` y termina con código de salida 1.

## Problemas y métodos

| Problema | Situación | Método |
|:---:|---|---|
| 1 | Sobrecorriente y sobretensión en un sistema de protección | Unión, complemento, exclusión mutua e independencia |
| 2 | Sensores de tres proveedores | Teorema de la probabilidad total y teorema de Bayes |
| 3 | Pérdida de paquetes en un enlace IoT | Frecuencia relativa, error estándar y Ley de los Grandes Números |
| 4 | Paquetes perdidos en 4 transmisiones | Distribución binomial y función de distribución acumulada |
| 5 | Tiempo de respuesta de un actuador | Variable continua: densidad, distribución acumulada y cuantiles |
| 6 | Fallas por ciclo de un sistema de transporte | Esperanza, varianza y desviación estándar |
| 7 | Velocidad de un motor | Transformación lineal Y = aX + b |
| 8 | Sensores, alarmas y tiempos de espera | Distribuciones binomial, de Poisson y exponencial |

## Figuras

**Figura 1.** Diagrama de Venn del Problema 1 (las áreas no son proporcionales a las probabilidades).

![Figura 1](figs/fig1_venn.png)

**Figura 2.** Diagrama de árbol del Problema 2: probabilidades conjuntas y P(D).

![Figura 2](figs/fig2_arbol.png)

**Figura 3.** Tasas de pérdida del Problema 3 con intervalos aproximados de 95 %.

![Figura 3](figs/fig3_intervalos.png)

**Figura 4.** Función de masa y función de distribución acumulada de X ~ Binomial(4, 0.15).

![Figura 4](figs/fig4_binomial.png)

**Figura 5.** Densidad y distribución acumulada del tiempo de respuesta del actuador (Problema 5).

![Figura 5](figs/fig5_densidad.png)

**Figura 6.** Modelos de las tres situaciones del Problema 8.

![Figura 6](figs/fig6_situaciones.png)

## Reproducibilidad

Resultados verificados con Python 3.13, numpy 2.5, scipy 1.18 y matplotlib 3.11. Los datos de entrada son los del enunciado de la asignación; no se usan datos externos.

## Licencia

MIT (ver `LICENSE`).
