"""
Asignación #1 · Módulo VIII — Principios de probabilidad y variables aleatorias
Métodos de Investigación Aplicada · Maestría en Ingeniería Eléctrica (UTP)
Autor: Eric Arosemena

Script único y reproducible que:
  1. Calcula todos los resultados numéricos de la solución (Problemas 1 a 8).
  2. Contrasta cada valor clave con el valor reportado en el documento.
  3. Genera las 6 figuras de apoyo; sus etiquetas salen de los mismos cálculos.

Requisitos: Python >= 3.10, numpy, scipy, matplotlib.

Uso:
  python asignacion1_completo.py                      # verificación + figuras PNG en ./figs
  python asignacion1_completo.py --solo-verificacion  # solo cálculos y comprobación
  python asignacion1_completo.py --solo-figuras       # solo figuras
  python asignacion1_completo.py --formato svg        # figuras vectoriales (svg o pdf)
  python asignacion1_completo.py --salida mis_figs    # otra carpeta de salida
  python asignacion1_completo.py --detalle            # imprime todos los valores sin redondear
"""
import argparse
import os
import sys
from fractions import Fraction as Fr
from math import comb, exp, pi, sqrt

import matplotlib

matplotlib.use("Agg")  # backend sin ventana: solo guarda archivos
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.patches import Circle, Patch, Rectangle
from scipy import stats
from scipy.integrate import quad


# =============================================================================
# 1. CÁLCULOS
# =============================================================================
def resolver():
    """Resuelve numéricamente los 8 problemas y devuelve un diccionario por problema."""
    R = {}

    # -- Problema 1: unión, complemento, diferencia e independencia ----------
    PA, PB, PAB = 0.18, 0.12, 0.04
    R["P1"] = {
        "P(A)": PA, "P(B)": PB, "P(A n B)": PAB,
        "P(A u B)": PA + PB - PAB,
        "P(Ac n Bc)": 1 - (PA + PB - PAB),
        "P(B n Ac)": PB - PAB,
        "P(A n Bc)": PA - PAB,
        "P(A)P(B)": PA * PB,
        "P(A|B)": PAB / PB,
        "P(B|A)": PAB / PA,
    }

    # -- Problema 2: probabilidad total y teorema de Bayes ----------------------
    prior = np.array([0.45, 0.35, 0.20])        # P(Pi)
    lik = np.array([0.02, 0.03, 0.06])          # P(D | Pi)
    joint = prior * lik                          # P(D n Pi)
    PD = joint.sum()                             # probabilidad total
    post = joint / PD                            # Bayes: P(Pi | D)
    R["P2"] = {"P(Pi)": prior, "P(D|Pi)": lik, "P(D n Pi)": joint, "P(D)": PD,
               "P(Pi|D)": post, "P(P3|D)/P(P3)": post[2] / prior[2]}

    # -- Problema 3: frecuencia relativa y variabilidad muestral ----------------
    n1, x1, n2, x2 = 900, 54, 1500, 75
    p1, p2 = x1 / n1, x2 / n2
    pc = (x1 + x2) / (n1 + n2)                   # tasa conjunta
    se1, se2 = sqrt(p1 * (1 - p1) / n1), sqrt(p2 * (1 - p2) / n2)
    se_c = sqrt(pc * (1 - pc) / (n1 + n2))
    se_diff = sqrt(pc * (1 - pc) * (1 / n1 + 1 / n2))   # bajo p común
    z = (p1 - p2) / se_diff
    mu1, sd1 = n1 * pc, sqrt(n1 * pc * (1 - pc))        # modelo binomial bajo p común
    mu2, sd2 = n2 * pc, sqrt(n2 * pc * (1 - pc))
    R["P3"] = {"n1": n1, "x1": x1, "n2": n2, "x2": x2,
               "p1": p1, "p2": p2, "p_conjunta": pc, "promedio simple": (p1 + p2) / 2,
               "SE1": se1, "SE2": se2, "SE conjunta": se_c, "SE diferencia": se_diff,
               "z": z, "valor p (z)": 2 * stats.norm.sf(abs(z)),
               # prueba exacta de Fisher: comprobación sin aproximación normal
               "valor p (Fisher)": stats.fisher_exact([[x1, n1 - x1], [x2, n2 - x2]]).pvalue,
               "E1": mu1, "sd1": sd1, "E2": mu2, "sd2": sd2,
               "z1": (x1 - mu1) / sd1, "z2": (x2 - mu2) / sd2}

    # -- Problema 4: X ~ Binomial(4, 0.15) --------------------------------------
    X4 = stats.binom(4, 0.15)
    pmf4 = np.array([X4.pmf(k) for k in range(5)])
    R["P4"] = {"pmf": pmf4,
               "pmf exacta": [comb(4, k) * Fr(15, 100) ** k * Fr(85, 100) ** (4 - k)
                              for k in range(5)],
               "suma": pmf4.sum(), "F": np.cumsum(pmf4),
               "P(X<=1)": X4.cdf(1), "P(X>=2)": X4.sf(1),
               "E[X]": X4.mean(), "Var(X)": X4.var(), "sigma": X4.std()}

    # -- Problema 5: densidad f(x) = x/72 en [0, 12] ----------------------------
    f5 = lambda x: x / 72 if 0 <= x <= 12 else 0.0
    F5 = lambda x: 0.0 if x < 0 else (x**2 / 144 if x <= 12 else 1.0)
    R["P5"] = {"area total": quad(f5, 0, 12)[0],
               "P(4<=X<=8)": quad(f5, 4, 8)[0], "F(8)-F(4)": F5(8) - F5(4),
               "F(4)": F5(4), "F(8)": F5(8), "F(9)": F5(9), "P(X>9)": 1 - F5(9),
               "f(8)": f5(8), "P(7.95<=X<=8.05)": F5(8.05) - F5(7.95),
               "E[X]": quad(lambda x: x * f5(x), 0, 12)[0],
               "mediana": sqrt(0.50 * 144), "P95": sqrt(0.95 * 144)}

    # -- Problema 6: esperanza y varianza de una distribución discreta ---------
    x6 = np.array([0, 1, 2, 3])
    p6 = np.array([0.45, 0.35, 0.15, 0.05])
    EX6 = (x6 * p6).sum()
    EX2_6 = (x6**2 * p6).sum()
    Var6 = EX2_6 - EX6**2
    R["P6"] = {"suma": p6.sum(), "E[X]": EX6, "E[X^2]": EX2_6, "Var": Var6,
               "Var (definición)": ((x6 - EX6) ** 2 * p6).sum(),
               "sigma": sqrt(Var6), "CV": sqrt(Var6) / EX6,
               "P(X>=1)": p6[1:].sum(), "P(X>=2)": p6[2:].sum()}

    # -- Problema 7: transformación lineal Y = aX + b ---------------------------
    a, b = 2 * pi / 60, 2.0
    EX7, sX7 = 1450.0, 40.0
    R["P7"] = {"a": a, "a*E[X]": a * EX7, "E[Y]": a * EX7 + b,
               "Var(Y)": a**2 * sX7**2, "sigma_Y": abs(a) * sX7,
               "CV X": sX7 / EX7, "CV aX": a * sX7 / (a * EX7),
               "CV Y": a * sX7 / (a * EX7 + b), "corrección en rpm": b / a}

    # -- Problema 8: Binomial, Poisson y Exponencial ----------------------------
    R["P8"] = {"Binom(12,0.1): P(X=3)": stats.binom.pmf(3, 12, 0.10),
               "Binom manual": comb(12, 3) * 0.1**3 * 0.9**9,
               "Binom E[X]": 12 * 0.1, "Binom sigma": sqrt(12 * 0.1 * 0.9),
               "Poisson(4): P(Y=6)": stats.poisson.pmf(6, 4),
               "Poisson manual": exp(-4) * 4**6 / 720,
               "Exp(4/h): P(T>1/3 h)": stats.expon.sf(1 / 3, scale=1 / 4),
               "Exp manual": exp(-4 / 3),
               "Poisson(4/3): P(N=0)": stats.poisson.pmf(0, 4 / 3),
               "E[T] (min)": 60 / 4}
    return R


# =============================================================================
# 2. COMPROBACIÓN CONTRA EL DOCUMENTO
# =============================================================================
# (literal, magnitud, cómo obtenerla de R, valor tal como aparece en el documento).
# La tolerancia es media unidad del último decimal reportado.
VALORES_DOCUMENTO = [
    ("1b", "P(A u B)", lambda R: R["P1"]["P(A u B)"], "0.2600"),
    ("1c", "P(A^c n B^c)", lambda R: R["P1"]["P(Ac n Bc)"], "0.7400"),
    ("1d", "P(B n A^c)", lambda R: R["P1"]["P(B n Ac)"], "0.0800"),
    ("1e", "P(A)P(B)", lambda R: R["P1"]["P(A)P(B)"], "0.0216"),
    ("1e", "P(A|B)", lambda R: R["P1"]["P(A|B)"], "0.3333"),
    ("1e", "P(B|A)", lambda R: R["P1"]["P(B|A)"], "0.2222"),
    ("2b", "P(D)", lambda R: R["P2"]["P(D)"], "0.0315"),
    ("2c", "P(P1|D)", lambda R: R["P2"]["P(Pi|D)"][0], "0.2857"),
    ("2c", "P(P2|D)", lambda R: R["P2"]["P(Pi|D)"][1], "0.3333"),
    ("2c", "P(P3|D)", lambda R: R["P2"]["P(Pi|D)"][2], "0.3810"),
    ("2d", "P(P3|D)/P(P3)", lambda R: R["P2"]["P(P3|D)/P(P3)"], "1.9048"),
    ("3a", "p1 estimada", lambda R: R["P3"]["p1"], "0.0600"),
    ("3a", "p2 estimada", lambda R: R["P3"]["p2"], "0.0500"),
    ("3b", "p conjunta", lambda R: R["P3"]["p_conjunta"], "0.05375"),
    ("3b", "promedio simple", lambda R: R["P3"]["promedio simple"], "0.0550"),
    ("3c", "E[X1] con p común", lambda R: R["P3"]["E1"], "48.38"),
    ("3c", "sigma1 con p común", lambda R: R["P3"]["sd1"], "6.77"),
    ("3c", "E[X2] con p común", lambda R: R["P3"]["E2"], "80.63"),
    ("3c", "sigma2 con p común", lambda R: R["P3"]["sd2"], "8.73"),
    ("3c", "desviación campaña 1", lambda R: R["P3"]["z1"], "0.83"),
    ("3c", "desviación campaña 2", lambda R: R["P3"]["z2"], "-0.64"),
    ("3c", "SE(p1 - p2)", lambda R: R["P3"]["SE diferencia"], "0.0095"),
    ("3c", "z", lambda R: R["P3"]["z"], "1.05"),
    ("3c", "valor p (z)", lambda R: R["P3"]["valor p (z)"], "0.29"),
    ("3c", "valor p (Fisher)", lambda R: R["P3"]["valor p (Fisher)"], "0.30"),
    ("3d", "SE campaña 1", lambda R: R["P3"]["SE1"], "0.0079"),
    ("3d", "SE campaña 2", lambda R: R["P3"]["SE2"], "0.0056"),
    ("3d", "SE conjunta", lambda R: R["P3"]["SE conjunta"], "0.0046"),
    ("4b", "P(X=0)", lambda R: R["P4"]["pmf"][0], "0.5220"),
    ("4b", "P(X=1)", lambda R: R["P4"]["pmf"][1], "0.3685"),
    ("4b", "P(X=2)", lambda R: R["P4"]["pmf"][2], "0.0975"),
    ("4b", "P(X=3)", lambda R: R["P4"]["pmf"][3], "0.0115"),
    ("4b", "P(X=4)", lambda R: R["P4"]["pmf"][4], "0.0005"),
    ("4b", "suma de p_X(k)", lambda R: R["P4"]["suma"], "1.0000"),
    ("4b", "sigma_X", lambda R: R["P4"]["sigma"], "0.7141"),
    ("4c", "P(X<=1) = F_X(1)", lambda R: R["P4"]["P(X<=1)"], "0.8905"),
    ("4c", "P(X>=2)", lambda R: R["P4"]["P(X>=2)"], "0.1095"),
    ("5a", "área total", lambda R: R["P5"]["area total"], "1.0000"),
    ("5c", "P(4<=X<=8)", lambda R: R["P5"]["P(4<=X<=8)"], "0.3333"),
    ("5d", "P(X>9)", lambda R: R["P5"]["P(X>9)"], "0.4375"),
    ("5d", "F_X(9)", lambda R: R["P5"]["F(9)"], "0.5625"),
    ("5d", "E[X] (s)", lambda R: R["P5"]["E[X]"], "8.0000"),
    ("5d", "mediana (s)", lambda R: R["P5"]["mediana"], "8.49"),
    ("5d", "percentil 95 (s)", lambda R: R["P5"]["P95"], "11.70"),
    ("5e", "f_X(8) (1/s)", lambda R: R["P5"]["f(8)"], "0.1111"),
    ("5e", "P(7.95<=X<=8.05)", lambda R: R["P5"]["P(7.95<=X<=8.05)"], "0.0111"),
    ("6b", "E[X]", lambda R: R["P6"]["E[X]"], "0.80"),
    ("6c", "E[X^2]", lambda R: R["P6"]["E[X^2]"], "1.40"),
    ("6c", "Var(X)", lambda R: R["P6"]["Var"], "0.76"),
    ("6c", "sigma_X", lambda R: R["P6"]["sigma"], "0.8718"),
    ("6c", "coef. de variación", lambda R: R["P6"]["CV"], "1.09"),
    ("6d", "P(X>=1)", lambda R: R["P6"]["P(X>=1)"], "0.55"),
    ("6d", "P(X>=2)", lambda R: R["P6"]["P(X>=2)"], "0.20"),
    ("7a", "E[Y] (rad/s)", lambda R: R["P7"]["E[Y]"], "153.8436"),
    ("7b", "Var(Y) (rad/s)^2", lambda R: R["P7"]["Var(Y)"], "17.5460"),
    ("7b", "sigma_Y (rad/s)", lambda R: R["P7"]["sigma_Y"], "4.1888"),
    ("7c", "a E[X] (rad/s)", lambda R: R["P7"]["a*E[X]"], "151.8436"),
    ("7c", "CV de X y de aX", lambda R: R["P7"]["CV X"], "0.0276"),
    ("7c", "CV de Y", lambda R: R["P7"]["CV Y"], "0.0272"),
    ("7c", "corrección (rpm)", lambda R: R["P7"]["corrección en rpm"], "19.1"),
    ("8a", "P(X=3)", lambda R: R["P8"]["Binom(12,0.1): P(X=3)"], "0.0852"),
    ("8a", "sigma_X", lambda R: R["P8"]["Binom sigma"], "1.04"),
    ("8b", "P(Y=6)", lambda R: R["P8"]["Poisson(4): P(Y=6)"], "0.1042"),
    ("8c", "P(T>20 min)", lambda R: R["P8"]["Exp(4/h): P(T>1/3 h)"], "0.2636"),
    ("8c", "E[T] (min)", lambda R: R["P8"]["E[T] (min)"], "15"),
]


def comprobar(R):
    """Compara cada valor calculado con el del documento; devuelve el número de diferencias."""
    print("Comprobación contra el documento (tolerancia: media unidad del último decimal)")
    print(f"  {'Lit.':<5}{'Magnitud':<22}{'Calculado':>14}{'Documento':>12}   Estado")
    fallos = 0
    for lit, nombre, obtener, reportado in VALORES_DOCUMENTO:
        valor = float(obtener(R))
        decimales = len(reportado.split(".")[1]) if "." in reportado else 0
        tolerancia = 0.5 * 10 ** (-decimales) + 1e-9
        ok = abs(valor - float(reportado)) <= tolerancia
        fallos += not ok
        print(f"  {lit:<5}{nombre:<22}{valor:>14.6f}{reportado:>12}   {'OK' if ok else 'DIFERENCIA'}")
    total = len(VALORES_DOCUMENTO)
    print(f"\n  {total - fallos} de {total} valores coinciden con el documento.")
    return fallos


def imprimir_detalle(R):
    """Imprime todos los valores calculados, sin redondear."""
    for problema, bloque in R.items():
        print(f"\n=== Problema {problema[1:]} ===")
        for clave, valor in bloque.items():
            print(f"  {clave:24s}: {valor}")
    print()


# =============================================================================
# 3. FIGURAS
# =============================================================================
BLUE, ORANGE = "#2a78d6", "#eb6834"          # paleta validada (contraste y daltonismo)
BLUE_LIGHT, ORANGE_LIGHT = "#cde2fb", "#fbe1d6"
INK, INK2, GRID, SPINE = "#0b0b0b", "#52514e", "#e4e3df", "#9a9893"


def configurar_estilo():
    """Estilo común; usa Calibri, Carlito (misma métrica que Calibri) o, si no, DejaVu Sans."""
    disponibles = {f.name for f in font_manager.fontManager.ttflist}
    fuente = next((f for f in ("Calibri", "Carlito") if f in disponibles), "DejaVu Sans")
    plt.rcParams.update({
        "font.family": fuente,
        "mathtext.fontset": "custom",
        "mathtext.rm": fuente,
        "mathtext.it": f"{fuente}:italic",
        "mathtext.bf": f"{fuente}:bold",
        "font.size": 9,
        "axes.titlesize": 9.5,
        "axes.labelsize": 9,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "axes.edgecolor": SPINE,
        "axes.labelcolor": INK2,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "text.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "axes.grid.axis": "y",
        "grid.color": GRID,
        "grid.linewidth": 0.6,
        "axes.axisbelow": True,
        "legend.frameon": False,
        "legend.fontsize": 8.5,
        "savefig.dpi": 220,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.04,
    })
    return fuente


def fig_venn(R, guardar):
    """Figura 1 — Diagrama de Venn del Problema 1."""
    d = R["P1"]
    fig, ax = plt.subplots(figsize=(6.3, 2.55))
    ax.set_xlim(0, 10); ax.set_ylim(0, 4.2); ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Rectangle((0.05, 0.05), 9.9, 4.1, fill=False, ec=SPINE, lw=1.0))
    ax.text(0.3, 3.75, r"$\Omega$", fontsize=13, color=INK2)
    ca, cb, r = (4.2, 2.05), (5.8, 2.05), 1.6
    ax.add_patch(Circle(ca, r, fc=BLUE, alpha=0.16, ec="none"))
    ax.add_patch(Circle(cb, r, fc=ORANGE, alpha=0.16, ec="none"))
    ax.add_patch(Circle(ca, r, fill=False, ec=BLUE, lw=1.6))
    ax.add_patch(Circle(cb, r, fill=False, ec=ORANGE, lw=1.6))
    kw = dict(ha="center", va="center", fontsize=9.5)
    ax.text(3.35, 2.05, f"$A\\cap B^{{c}}$\n{d['P(A n Bc)']:.2f}", **kw)
    ax.text(5.0, 2.05, f"$A\\cap B$\n{d['P(A n B)']:.2f}", **kw)
    ax.text(6.65, 2.05, f"$B\\cap A^{{c}}$\n{d['P(B n Ac)']:.2f}", **kw)
    ax.text(1.55, 3.05, f"A: sobrecorriente\nP(A) = {d['P(A)']:.2f}", ha="center",
            fontsize=9, color=INK)
    ax.text(8.45, 3.05, f"B: sobretensión\nP(B) = {d['P(B)']:.2f}", ha="center",
            fontsize=9, color=INK)
    ax.plot([2.35, 2.95], [2.95, 2.75], color=BLUE, lw=1.0)
    ax.plot([7.65, 7.05], [2.95, 2.75], color=ORANGE, lw=1.0)
    ax.text(8.45, 0.45, f"$(A\\cup B)^{{c}}$ = {d['P(Ac n Bc)']:.2f}", ha="center", fontsize=9.5)
    guardar(fig, "fig1_venn")


def fig_arbol(R, guardar):
    """Figura 2 — Diagrama de árbol del Problema 2."""
    d = R["P2"]
    fig, ax = plt.subplots(figsize=(6.3, 3.15))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(0.075, 0.5, "Sensor\nal azar", ha="center", va="center", fontsize=9,
            bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=SPINE, lw=0.8))
    for i, (y, pp, dd) in enumerate(zip((0.84, 0.50, 0.16), d["P(Pi)"], d["P(D|Pi)"]), start=1):
        ax.plot([0.13, 0.285], [0.5, y], color=SPINE, lw=1.1)
        ax.text(0.205, (0.5 + y) / 2 + (0.035 if y > 0.5 else -0.035 if y < 0.5 else 0.03),
                f"{pp:.2f}", ha="center", va="center", fontsize=8.5, color=INK2,
                bbox=dict(fc="white", ec="none", pad=0.6))
        ax.text(0.305, y, f"$P_{i}$", ha="center", va="center", fontsize=10.5)
        ramas = [(+1, "$D$", dd, pp * dd, ORANGE), (-1, "$D^{c}$", 1 - dd, pp * (1 - dd), SPINE)]
        for signo, evento, pcond, pconj, color in ramas:
            y2 = y + signo * 0.085
            ax.plot([0.33, 0.495], [y, y2], color=color, lw=1.6 if signo > 0 else 1.1)
            ax.text(0.412, (y + y2) / 2 + signo * 0.03, f"{pcond:.2f}", ha="center", va="center",
                    fontsize=8.5, color=INK2, bbox=dict(fc="white", ec="none", pad=0.5))
            ax.text(0.515, y2, evento, ha="left", va="center", fontsize=10)
            if signo > 0:
                txt = f"$P(P_{i}\\cap D)$ = {pp:.2f} × {pcond:.2f} = {pconj:.4f}"
                ax.plot(0.567, y2, "o", ms=4.5, color=ORANGE)
            else:
                txt = f"$P(P_{i}\\cap D^{{c}})$ = {pconj:.4f}"
            ax.text(0.585, y2, txt, ha="left", va="center", fontsize=8.6,
                    color=INK if signo > 0 else INK2, fontweight="bold" if signo > 0 else "normal")
    suma = " + ".join(f"{j:.4f}" for j in d["P(D n Pi)"])
    ax.text(0.585, 0.0, f"P(D) = {suma} = {d['P(D)']:.4f}",
            ha="left", va="center", fontsize=9, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.35", fc=ORANGE_LIGHT, ec=ORANGE, lw=0.8))
    guardar(fig, "fig2_arbol")


def fig_intervalos(R, guardar):
    """Figura 3 — Tasas de pérdida con intervalos aproximados de 95 % (Problema 3)."""
    d = R["P3"]
    n_tot = d["n1"] + d["n2"]
    filas = [(f"Conjunta (n = {n_tot})", d["p_conjunta"], n_tot),
             (f"Campaña 2 (n = {d['n2']})", d["p2"], d["n2"]),
             (f"Campaña 1 (n = {d['n1']})", d["p1"], d["n1"])]
    fig, ax = plt.subplots(figsize=(6.3, 2.05))
    pc = d["p_conjunta"]
    ax.axvline(pc * 100, color=INK2, lw=1.0, ls=(0, (4, 3)))
    ax.text(pc * 100, 2.62, f"  $\\hat{{p}}_c$ = {pc * 100:.3f} % (supuesto de p común)",
            fontsize=8.3, color=INK2, va="center", ha="left")
    for i, (etiqueta, p, n) in enumerate(filas):
        se = np.sqrt(p * (1 - p) / n)
        lo, hi = (p - 1.96 * se) * 100, (p + 1.96 * se) * 100
        color = INK2 if i == 0 else BLUE
        ax.plot([lo, hi], [i, i], color=color, lw=2.2, solid_capstyle="round")
        ax.plot(p * 100, i, "o", ms=8, color=color, mec="white", mew=1.6)
        pf = f"{p * 100:.3f}" if i == 0 else f"{p * 100:.2f}"
        ax.text(hi + 0.12, i, f"{pf} %  [{lo:.2f}; {hi:.2f}]", va="center", fontsize=8.5)
    ax.set_yticks(range(3)); ax.set_yticklabels([f[0] for f in filas])
    ax.set_ylim(-0.6, 2.95); ax.set_xlim(3.4, 9.6)
    ax.grid(axis="x"); ax.grid(axis="y", visible=False)
    ax.set_xlabel("Tasa de pérdida de paquetes (%)  ·  punto: $\\hat{p}$   "
                  "barra: $\\hat{p} \\pm 1.96\\,SE$")
    guardar(fig, "fig3_intervalos")


def fig_binomial4(R, guardar):
    """Figura 4 — Función de masa y acumulada de X ~ Binomial(4, 0.15) (Problema 4)."""
    d = R["P4"]
    k = np.arange(5)
    pmf, cdf = d["pmf"], d["F"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.3, 2.45), gridspec_kw=dict(wspace=0.32))
    a1.bar(k, pmf, width=0.62, color=[BLUE if kk <= 1 else ORANGE for kk in k],
           edgecolor="white", linewidth=1.5)
    for kk, v in zip(k, pmf):
        a1.text(kk, v + 0.015, f"{v:.4f}", ha="center", va="bottom", fontsize=8.2)
    a1.set_xticks(k); a1.set_ylim(0, 0.62)
    a1.set_xlabel("k (paquetes perdidos)"); a1.set_ylabel("$p_X(k) = P(X = k)$")
    a1.set_title("(a) Función de masa", loc="left", color=INK)
    a1.legend(handles=[Patch(color=BLUE, label=f"$X \\leq 1$: {d['P(X<=1)']:.4f}"),
                       Patch(color=ORANGE, label=f"$X \\geq 2$: {d['P(X>=2)']:.4f}")],
              loc="upper right", handlelength=1.0)
    xs = [-0.6] + list(k) + [4.6]                # función acumulada escalonada
    niveles = [0.0] + list(cdf)
    for i in range(len(niveles)):
        a2.plot([xs[i], xs[i + 1]], [niveles[i], niveles[i]], color=BLUE, lw=2)
    a2.plot(k, cdf, "o", ms=5.5, color=BLUE)                                         # incluido
    a2.plot(k, [0] + list(cdf[:-1]), "o", ms=5.5, mfc="white", mec=BLUE, mew=1.3)    # excluido
    a2.plot([-0.6, 1], [cdf[1], cdf[1]], color=ORANGE, lw=1.0, ls=(0, (3, 2)))
    a2.annotate(f"$F_X(1)$ = {cdf[1]:.4f}", xy=(1.0, cdf[1]), xytext=(1.55, 0.62), fontsize=8.6,
                arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8))
    a2.set_xticks(k); a2.set_ylim(-0.03, 1.08); a2.set_xlim(-0.6, 4.6)
    a2.set_xlabel("x"); a2.set_ylabel("$F_X(x) = P(X \\leq x)$")
    a2.set_title("(b) Función de distribución acumulada", loc="left", color=INK)
    guardar(fig, "fig4_binomial")


def fig_densidad(R, guardar):
    """Figura 5 — Densidad y distribución acumulada del tiempo de respuesta (Problema 5)."""
    d = R["P5"]
    x = np.linspace(0, 12, 400)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.3, 2.55), gridspec_kw=dict(wspace=0.3))
    a1.plot([-1, 0], [0, 0], color=BLUE, lw=2); a1.plot([12, 13], [0, 0], color=BLUE, lw=2)
    a1.plot([12, 12], [0, 12 / 72], color=BLUE, lw=1, ls=(0, (2, 2)))
    xm = np.linspace(4, 8, 100)
    a1.fill_between(xm, xm / 72, color=BLUE_LIGHT, lw=0)
    xt = np.linspace(9, 12, 100)
    a1.fill_between(xt, xt / 72, facecolor=ORANGE_LIGHT, edgecolor=ORANGE, hatch="////", lw=0)
    a1.plot(x, x / 72, color=BLUE, lw=2)
    a1.axvline(9, color=INK2, lw=0.9, ls=(0, (4, 3)))
    a1.text(9.1, 0.178, "límite\n9 s", fontsize=8, color=INK2, va="top")
    a1.text(6.0, 0.035, f"{d['P(4<=X<=8)']:.4f}", ha="center", fontsize=8.8, fontweight="bold")
    a1.text(10.55, 0.05, f"{d['P(X>9)']:.4f}", ha="center", fontsize=8.8, fontweight="bold",
            bbox=dict(fc="white", ec="none", pad=0.8))
    a1.set_xlim(-1, 13); a1.set_ylim(0, 0.19)
    a1.set_xlabel("x (s)"); a1.set_ylabel("$f_X(x)$  [s$^{-1}$]")
    a1.set_title("(a) Densidad: área = probabilidad", loc="left", color=INK)
    X = np.linspace(-1, 13, 500)
    a2.plot(X, np.where(X < 0, 0, np.where(X <= 12, X**2 / 144, 1)), color=BLUE, lw=2)
    for xv in (4, 8, 9):
        yv = xv**2 / 144
        a2.plot([xv, xv], [0, yv], color=SPINE, lw=0.8, ls=(0, (2, 2)))
        a2.plot([-1, xv], [yv, yv], color=SPINE, lw=0.8, ls=(0, (2, 2)))
        a2.plot(xv, yv, "o", ms=5, color=ORANGE if xv == 9 else BLUE)
    a2.text(3.0, 0.17, f"F(4) = {d['F(4)']:.4f}", fontsize=8.2, ha="right")
    a2.text(7.0, 0.36, f"F(8) = {d['F(8)']:.4f}", fontsize=8.2, ha="right")
    a2.text(9.4, 0.53, f"F(9) = {d['F(9)']:.4f}", fontsize=8.2, ha="left")
    a2.set_xlim(-1, 13); a2.set_ylim(-0.02, 1.06)
    a2.set_xlabel("x (s)"); a2.set_ylabel("$F_X(x) = P(X \\leq x)$")
    a2.set_title("(b) Distribución acumulada", loc="left", color=INK)
    guardar(fig, "fig5_densidad")


def fig_situaciones(R, guardar):
    """Figura 6 — Binomial, Poisson y Exponencial de las tres situaciones (Problema 8)."""
    d = R["P8"]
    fig, axs = plt.subplots(1, 3, figsize=(6.3, 2.25), gridspec_kw=dict(wspace=0.38))
    k1 = np.arange(0, 8)
    p1 = stats.binom.pmf(k1, 12, 0.10)
    axs[0].bar(k1, p1, width=0.66, color=[ORANGE if k == 3 else BLUE for k in k1],
               edgecolor="white", linewidth=1.2)
    axs[0].text(2.72, p1[3] + 0.02, f"{d['Binom(12,0.1): P(X=3)']:.4f}", ha="left",
                fontsize=8.2, fontweight="bold")
    axs[0].set_title("Sit. 1 · Binomial(12, 0.10)", loc="left", color=INK, fontsize=8.8)
    axs[0].set_xlabel("x (sensores defectuosos)"); axs[0].set_ylabel("P(X = x)")
    axs[0].set_xticks(k1); axs[0].set_ylim(0, 0.45)
    k2 = np.arange(0, 13)
    p2 = stats.poisson.pmf(k2, 4)
    axs[1].bar(k2, p2, width=0.66, color=[ORANGE if k == 6 else BLUE for k in k2],
               edgecolor="white", linewidth=1.0)
    axs[1].text(5.72, p2[6] + 0.012, f"{d['Poisson(4): P(Y=6)']:.4f}", ha="left",
                fontsize=8.2, fontweight="bold")
    axs[1].set_title("Sit. 2 · Poisson(λ = 4)", loc="left", color=INK, fontsize=8.8)
    axs[1].set_xlabel("y (alarmas en 1 h)"); axs[1].set_ylabel("P(Y = y)")
    axs[1].set_xticks(range(0, 13, 2)); axs[1].set_ylim(0, 0.25)
    t = np.linspace(0, 75, 400)
    lam = 1 / d["E[T] (min)"]                    # tasa en min^-1 (1/15)
    axs[2].plot(t, lam * np.exp(-lam * t), color=BLUE, lw=2)
    tt = np.linspace(20, 75, 200)
    axs[2].fill_between(tt, lam * np.exp(-lam * tt), facecolor=ORANGE_LIGHT, edgecolor=ORANGE,
                        hatch="////", lw=0)
    axs[2].axvline(20, color=INK2, lw=0.9, ls=(0, (4, 3)))
    axs[2].text(36, 0.022, f"P(T > 20)\n= {d['Exp(4/h): P(T>1/3 h)']:.4f}", fontsize=8.2,
                fontweight="bold", ha="left")
    axs[2].set_title("Sit. 3 · Exponencial(4 h⁻¹)", loc="left", color=INK, fontsize=8.8)
    axs[2].set_xlabel("t (min)"); axs[2].set_ylabel("$f_T(t)$  [min$^{-1}$]")
    axs[2].set_xlim(0, 75); axs[2].set_ylim(0, 0.072); axs[2].set_xticks([0, 20, 40, 60])
    guardar(fig, "fig6_situaciones")


def generar_figuras(R, carpeta="figs", formato="png"):
    """Genera las 6 figuras en `carpeta` con el formato indicado; devuelve las rutas."""
    configurar_estilo()
    os.makedirs(carpeta, exist_ok=True)
    rutas = []

    def guardar(fig, nombre):
        ruta = os.path.join(carpeta, f"{nombre}.{formato}")
        fig.savefig(ruta, facecolor="white")
        plt.close(fig)
        rutas.append(ruta)

    for figura in (fig_venn, fig_arbol, fig_intervalos, fig_binomial4, fig_densidad,
                   fig_situaciones):
        figura(R, guardar)
    return rutas


# =============================================================================
# 4. EJECUCIÓN
# =============================================================================
def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")   # acentos en consolas de Windows
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(
        description="Verificación numérica y figuras de la Asignación #1 (Módulo VIII).")
    modo = ap.add_mutually_exclusive_group()
    modo.add_argument("--solo-verificacion", action="store_true",
                      help="solo cálculos y comprobación contra el documento")
    modo.add_argument("--solo-figuras", action="store_true", help="solo genera las figuras")
    ap.add_argument("--salida", default="figs", help="carpeta de las figuras (por defecto: figs)")
    ap.add_argument("--formato", default="png", choices=["png", "svg", "pdf"],
                    help="formato de las figuras (por defecto: png)")
    ap.add_argument("--detalle", action="store_true",
                    help="imprime todos los valores calculados sin redondear")
    args = ap.parse_args(argv)

    R = resolver()
    fallos = 0
    if not args.solo_figuras:
        if args.detalle:
            imprimir_detalle(R)
        fallos = comprobar(R)
    if not args.solo_verificacion:
        rutas = generar_figuras(R, args.salida, args.formato)
        print(f"\nFiguras generadas en '{args.salida}': "
              + ", ".join(os.path.basename(r) for r in rutas))
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
